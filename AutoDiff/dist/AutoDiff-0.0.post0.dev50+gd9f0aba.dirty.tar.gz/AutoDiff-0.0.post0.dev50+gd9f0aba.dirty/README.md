# cs107-FinalProject

[![Codecov](https://codecov.io/gh/merlionctc/cs107-FinalProject/branch/master/graph/badge.svg?token=OK5DF8VBMO)](undefined)
[![Build Status](https://travis-ci.com/merlionctc/cs107-FinalProject.svg?token=GoqM45ZYtzxFGATTpCrx&branch=master)](https://travis-ci.com/merlionctc/cs107-FinalProject)

final project
Group 9

Group Member: 
* Jiahui Tang
* Wenqi Chen
* Yujie Cai


